package com.cts.homeservice.service;

import java.io.IOException;
import java.text.ParseException;

import org.json.JSONException;

public interface LocationService {

	public String getLatLong(String locality)throws IOException, JSONException, ParseException;
	public String getVicinity(String latLong)throws IOException, JSONException, ParseException;
	
}
