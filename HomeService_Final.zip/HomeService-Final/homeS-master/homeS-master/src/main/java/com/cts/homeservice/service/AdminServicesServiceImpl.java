package com.cts.homeservice.service;

public class AdminServicesServiceImpl implements AdminServicesService {

}
