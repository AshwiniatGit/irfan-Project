package com.cts.homeservice.service;

public interface AdminServicesService {

}
